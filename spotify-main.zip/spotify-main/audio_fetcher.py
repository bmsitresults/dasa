"""
Audio Fetcher with iTunes API integration and local JSON caching.
Retrieves real 30-second audio preview streams and high-resolution album artwork.
"""

import json
import os
import re
import requests
from typing import Dict, Optional, Tuple

CACHE_FILE = "audio_cache.json"

# In-memory cache
_cache: Dict[str, dict] = {}

def load_cache():
    global _cache
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                _cache = json.load(f)
        except Exception as e:
            print(f"Error loading audio cache: {e}")
            _cache = {}

def save_cache():
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(_cache, f, indent=2)
    except Exception as e:
        print(f"Error saving audio cache: {e}")

load_cache()

def clean_title(title: str) -> str:
    """Clean track title by removing remix tags, ft, etc. for fallback search."""
    cleaned = re.sub(r"\(feat\.[^)]*\)", "", title, flags=re.IGNORECASE)
    cleaned = re.sub(r"\[feat\.[^\]]*\]", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\(with[^)]*\)", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"- .*Remix.*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\(.*Remix.*\)", "", cleaned, flags=re.IGNORECASE)
    return cleaned.strip()

def get_audio_and_artwork(track_name: str, track_artist: str) -> Dict[str, Optional[str]]:
    """
    Search iTunes API for track preview and high-res artwork.
    Uses in-memory + disk cache to avoid redundant API hits.
    """
    cache_key = f"{track_name.strip().lower()}:::{track_artist.strip().lower()}"
    
    if cache_key in _cache:
        return _cache[cache_key]
    
    # Try primary search: full track name and artist
    queries = [
        f"{track_name} {track_artist}",
        f"{clean_title(track_name)} {track_artist}",
        f"{track_name}"
    ]
    
    for query in queries:
        try:
            resp = requests.get(
                "https://itunes.apple.com/search",
                params={"term": query, "entity": "song", "limit": 1},
                timeout=4
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("resultCount", 0) > 0:
                    result = data["results"][0]
                    preview_url = result.get("previewUrl")
                    # Convert 100x100 artwork to 600x600 high resolution
                    artwork_url = result.get("artworkUrl100", "")
                    if artwork_url:
                        artwork_url = artwork_url.replace("100x100bb.jpg", "600x600bb.jpg")
                    
                    data_obj = {
                        "preview_url": preview_url,
                        "artwork_url": artwork_url,
                        "track_name": result.get("trackName", track_name),
                        "artist_name": result.get("artistName", track_artist),
                        "collection_name": result.get("collectionName", ""),
                        "found": True
                    }
                    _cache[cache_key] = data_obj
                    if len(_cache) % 10 == 0:
                        save_cache()
                    return data_obj
        except Exception:
            pass
            
    # Fallback placeholder if not found on iTunes
    fallback_obj = {
        "preview_url": None,
        "artwork_url": None,
        "track_name": track_name,
        "artist_name": track_artist,
        "collection_name": "",
        "found": False
    }
    _cache[cache_key] = fallback_obj
    return fallback_obj

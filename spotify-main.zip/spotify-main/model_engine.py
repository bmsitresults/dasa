"""
Recommendation & ML Engine for Spotify-like Web Interface
DSA2 Project: Graph Data Structures, Dijkstra's Algorithm with Min-Heap,
K-Means Clustering, and Multi-Parametric Music Transition Engine.
"""

import heapq
import time
import math
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors

CSV_PATH = "major_project.csv"

FEATURE_COLS = [
    'danceability', 'energy', 'valence', 'tempo', 
    'acousticness', 'instrumentalness', 'loudness', 
    'speechiness', 'liveness'
]

MOOD_METADATA = {
    0: {
        "name": "Groovy Pop & Urban Rhythm",
        "description": "Catchy hooks, rhythmic bounce, and vibrant modern beats.",
        "color": "#F59E0B",
        "icon": "✨"
    },
    1: {
        "name": "High-Energy Workout & Rock",
        "description": "Pulsing guitar riffs, driving drums, and adrenaline-pumping intensity.",
        "color": "#EF4444",
        "icon": "⚡"
    },
    2: {
        "name": "Sunset Chill & Melodic Pop",
        "description": "Smooth warm chords, breezy melodies, and relaxed easy-going rhythm.",
        "color": "#EC4899",
        "icon": "🌅"
    },
    3: {
        "name": "Euphoric Dance & Party",
        "description": "Peak festival bangers, thumping kicks, and unstoppable euphoric dance energy.",
        "color": "#1DB954",
        "icon": "💃"
    },
    4: {
        "name": "Acoustic, Lo-Fi & Melancholic",
        "description": "Introspective piano, gentle strings, intimate vocals, and heartfelt storytelling.",
        "color": "#6366F1",
        "icon": "🌧️"
    },
    5: {
        "name": "Deep Electronic & Bass Club",
        "description": "Hypnotic synth lines, deep sub-bass, and futuristic electronic soundscapes.",
        "color": "#8B5CF6",
        "icon": "🪐"
    }
}

class MinHeap:
    """Min-Heap priority queue implementation for Dijkstra's algorithm."""
    def __init__(self):
        self.heap = []
    
    def push(self, distance: float, item: Any):
        heapq.heappush(self.heap, (distance, item))
        
    def pop(self) -> Tuple[float, Any]:
        return heapq.heappop(self.heap)
        
    def is_empty(self) -> bool:
        return len(self.heap) == 0

class MusicModelEngine:
    def __init__(self, csv_path: str = CSV_PATH):
        self.csv_path = csv_path
        self.df: Optional[pd.DataFrame] = None
        self.scaler = StandardScaler()
        self.feature_matrix: Optional[np.ndarray] = None
        self.kmeans: Optional[KMeans] = None
        self.nn_model: Optional[NearestNeighbors] = None
        self.graph_adj: Dict[int, List[Tuple[int, float]]] = {}
        self.is_ready = False
        
        self.load_and_train()

    def load_and_train(self):
        print("[Music Engine] Loading and cleaning dataset...")
        t0 = time.time()
        
        df = pd.read_csv(self.csv_path)
        # Drop missing track titles / artists
        df = df.dropna(subset=['track_name', 'track_artist'])
        # Deduplicate identical track name and artist combinations
        df = df.drop_duplicates(subset=['track_name', 'track_artist']).reset_index(drop=True)
        
        # Clean numeric feature columns
        for col in FEATURE_COLS + ['key', 'mode', 'duration_ms', 'track_popularity']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
                
        # Assign numeric ID (0-indexed integer for fast array lookups)
        df['id'] = df.index
        
        print(f"[Music Engine] Loaded {len(df):,} unique tracks in {time.time() - t0:.2f}s")
        
        # Extract features and fit standard scaler
        print("[Music Engine] Training ML models (StandardScaler, KMeans, NearestNeighbors)...")
        t1 = time.time()
        raw_features = df[FEATURE_COLS].values
        self.feature_matrix = self.scaler.fit_transform(raw_features)
        
        # Train KMeans for Mood Archetypes
        self.kmeans = KMeans(n_clusters=6, random_state=42, n_init='auto')
        df['mood_cluster'] = self.kmeans.fit_predict(self.feature_matrix)
        
        # Compute Russell Circumplex Mood Quadrant (Valence vs Energy)
        def get_circumplex(val, nrg):
            if val >= 0.5 and nrg >= 0.5:
                return "Euphoric & Exuberant"
            elif val < 0.5 and nrg >= 0.5:
                return "Intense & Fierce"
            elif val < 0.5 and nrg < 0.5:
                return "Melancholic & Reflective"
            else:
                return "Peaceful & Serene"
                
        df['affect_quadrant'] = [get_circumplex(v, e) for v, e in zip(df['valence'], df['energy'])]
        
        # Train NearestNeighbors with Cosine distance
        self.nn_model = NearestNeighbors(n_neighbors=25, metric='cosine', algorithm='auto')
        self.nn_model.fit(self.feature_matrix)
        
        print(f"[Music Engine] ML training completed in {time.time() - t1:.2f}s")
        
        self.df = df
        self.is_ready = True

    def get_song(self, song_id: int) -> Optional[Dict[str, Any]]:
        """Get full song dictionary by integer ID."""
        if self.df is None or song_id < 0 or song_id >= len(self.df):
            return None
        row = self.df.iloc[song_id]
        cluster_id = int(row['mood_cluster'])
        mood_meta = MOOD_METADATA.get(cluster_id, MOOD_METADATA[0])
        
        # Normalize tempo (between 60 and 200) to 0.0-1.0
        tempo_norm = min(max((row['tempo'] - 60) / 140.0, 0.0), 1.0)
        
        # Duration formatted (mm:ss)
        duration_sec = int(row['duration_ms'] / 1000)
        dur_min = duration_sec // 60
        dur_rem = duration_sec % 60
        duration_fmt = f"{dur_min}:{dur_rem:02d}"

        return {
            "id": int(row['id']),
            "track_id": str(row['track_id']),
            "title": str(row['track_name']),
            "artist": str(row['track_artist']),
            "album": str(row.get('track_album_name', 'Single')),
            "genre": str(row.get('playlist_genre', 'Pop')).title(),
            "subgenre": str(row.get('playlist_subgenre', '')).title(),
            "popularity": int(row.get('track_popularity', 50)),
            "duration_ms": int(row['duration_ms']),
            "duration_formatted": duration_fmt,
            "tempo": round(float(row['tempo']), 1),
            "key": int(row.get('key', 0)),
            "mode": int(row.get('mode', 1)),
            "danceability": round(float(row['danceability']), 3),
            "energy": round(float(row['energy']), 3),
            "valence": round(float(row['valence']), 3),
            "acousticness": round(float(row['acousticness']), 3),
            "instrumentalness": round(float(row['instrumentalness']), 3),
            "speechiness": round(float(row['speechiness']), 3),
            "loudness": round(float(row['loudness']), 1),
            "liveness": round(float(row['liveness']), 3),
            "mood_cluster": cluster_id,
            "mood_name": mood_meta["name"],
            "mood_desc": mood_meta["description"],
            "mood_color": mood_meta["color"],
            "mood_icon": mood_meta["icon"],
            "affect_quadrant": str(row['affect_quadrant']),
            "radar_vector": {
                "danceability": round(float(row['danceability']), 3),
                "energy": round(float(row['energy']), 3),
                "valence": round(float(row['valence']), 3),
                "acousticness": round(float(row['acousticness']), 3),
                "tempo_norm": round(tempo_norm, 3),
                "speechiness": round(float(row['speechiness']), 3)
            }
        }

    def search_songs(self, query: str = "", genre: str = "", mood_cluster: Optional[int] = None, 
                     limit: int = 20, offset: int = 0) -> Dict[str, Any]:
        """Search and filter songs in the library."""
        if self.df is None:
            return {"total": 0, "songs": []}
            
        sub = self.df
        
        if query:
            q = query.strip().lower()
            mask = (
                sub['track_name'].str.lower().str.contains(q, na=False) |
                sub['track_artist'].str.lower().str.contains(q, na=False) |
                sub['track_album_name'].str.lower().str.contains(q, na=False)
            )
            sub = sub[mask]
            
        if genre and genre.lower() != 'all':
            sub = sub[sub['playlist_genre'].str.lower() == genre.lower()]
            
        if mood_cluster is not None and mood_cluster >= 0:
            sub = sub[sub['mood_cluster'] == mood_cluster]
            
        total = len(sub)
        # Order by popularity descending
        sub = sub.sort_values(by='track_popularity', ascending=False)
        sliced = sub.iloc[offset:offset + limit]
        
        songs = [self.get_song(idx) for idx in sliced.index]
        return {
            "total": total,
            "count": len(songs),
            "offset": offset,
            "songs": [s for s in songs if s is not None]
        }

    def explain_transition(self, current: Dict[str, Any], next_song: Dict[str, Any], 
                           cosine_dist: float, mode: str) -> Dict[str, Any]:
        """
        Synthesizes the algorithmic thought process and mathematical explanation
        for why the next song was chosen.
        """
        match_pct = max(0, min(100, round((1.0 - cosine_dist) * 100, 1)))
        
        # Calculate parameter deltas
        delta_tempo = round(next_song['tempo'] - current['tempo'], 1)
        delta_energy = round(next_song['energy'] - current['energy'], 3)
        delta_valence = round(next_song['valence'] - current['valence'], 3)
        delta_dance = round(next_song['danceability'] - current['danceability'], 3)
        
        thoughts = []
        
        # Mood continuity or shift explanation
        if current['mood_cluster'] == next_song['mood_cluster']:
            thoughts.append(f"Mood Lock: Retains '{current['mood_name']}' aesthetic for uninterrupted emotional continuity.")
        else:
            thoughts.append(f"Mood Evolution: Smoothly bridges from '{current['mood_name']}' to '{next_song['mood_name']}'.")
            
        # Tempo & Beatmatching rationale
        bpm_diff_pct = abs(delta_tempo) / max(current['tempo'], 1) * 100
        if bpm_diff_pct <= 3.0:
            thoughts.append(f"BPM Synchronization: Near-flawless tempo alignment ({current['tempo']} -> {next_song['tempo']} BPM, {delta_tempo:+} BPM) preserves kinetic groove.")
        elif delta_tempo > 0:
            thoughts.append(f"Tempo Acceleration: Gently ramps up tempo ({current['tempo']} -> {next_song['tempo']} BPM, +{delta_tempo} BPM) to inject forward motion.")
        else:
            thoughts.append(f"Tempo Deceleration: Eases tempo ({current['tempo']} -> {next_song['tempo']} BPM, {delta_tempo} BPM) for a more relaxed groove.")
            
        # Energy dynamic flow
        if abs(delta_energy) < 0.08:
            thoughts.append(f"Energy Stability: Consistent energy plateau ({current['energy']*100:.0f}% -> {next_song['energy']*100:.0f}%) ensures zero abrupt drop-offs.")
        elif delta_energy > 0:
            thoughts.append(f"Energy Lift: Builds emotional momentum (+{delta_energy*100:.1f}% energy lift).")
        else:
            thoughts.append(f"Energy Release: Subtly mellows the atmosphere ({delta_energy*100:.1f}% energy dip).")
            
        # Harmonic compatibility
        key_names = ["C", "C#/Db", "D", "D#/Eb", "E", "F", "F#/Gb", "G", "G#/Ab", "A", "A#/Bb", "B"]
        curr_key = key_names[current['key'] % 12] + (" Major" if current['mode'] == 1 else " Minor")
        next_key = key_names[next_song['key'] % 12] + (" Major" if next_song['mode'] == 1 else " Minor")
        if current['key'] == next_song['key']:
            thoughts.append(f"Harmonic Lock: Both tracks share root key {curr_key} for zero harmonic dissonance.")
        else:
            thoughts.append(f"Key Progression: Musical transition from {curr_key} to {next_key}.")

        # Strategy summary
        strategy_desc = {
            "flow": "Optimal Mood & Parameter Continuity (Cosine Vector Minimization)",
            "energy_boost": "Dynamic Energy Elevation (+15% Target Energy & Tempo Drift)",
            "chill": "Acoustic Warmth & Gentle Energy Wind-Down",
            "harmonic": "Harmonic Key Compatibility & DJ Beatmixing",
            "adventurous": "Cross-Genre Valence & Groove Exploration"
        }.get(mode, "Intelligent Flow Matching")

        return {
            "match_percentage": match_pct,
            "cosine_distance": round(float(cosine_dist), 4),
            "mode": mode,
            "strategy": strategy_desc,
            "deltas": {
                "tempo": delta_tempo,
                "energy": delta_energy,
                "valence": delta_valence,
                "danceability": delta_dance
            },
            "thoughts": thoughts,
            "comparison": {
                "current": current['radar_vector'],
                "next": next_song['radar_vector']
            }
        }

    def get_next_recommendations(self, song_id: int, mode: str = "flow", count: int = 10) -> Dict[str, Any]:
        """
        The core "Next Songs Thinking" algorithm.
        Designs the upcoming playlist flow based on the current song's parameters and selected transition mode.
        """
        current_song = self.get_song(song_id)
        if not current_song or self.feature_matrix is None or self.df is None:
            return {"current_song": None, "recommendations": []}
            
        curr_vec = self.feature_matrix[song_id].copy()
        
        # Modify target vector based on transition mode
        target_vec = curr_vec.copy()
        
        if mode == "energy_boost":
            # Boost energy (idx 1), tempo (idx 3), danceability (idx 0)
            target_vec[1] += 0.8  # standardized energy shift
            target_vec[3] += 0.5  # standardized tempo shift
        elif mode == "chill":
            # Lower energy (idx 1), boost acousticness (idx 4), decrease tempo (idx 3)
            target_vec[1] -= 1.0
            target_vec[4] += 1.2
            target_vec[3] -= 0.5
        elif mode == "adventurous":
            # Keep valence & danceability, allow higher variance on genre/instrumentation
            target_vec[2] += 0.3  # slight valence lift
            
        # Search Nearest Neighbors
        # Fetch extra neighbors to filter out same artist or duplicate tracks
        n_fetch = min(count * 5, len(self.df))
        distances, indices = self.nn_model.kneighbors([target_vec], n_neighbors=n_fetch)
        
        distances = distances[0]
        indices = indices[0]
        
        seen_artists = {current_song['artist'].lower()}
        recommendations = []
        
        for dist, idx in zip(distances, indices):
            if idx == song_id:
                continue
            cand_song = self.get_song(idx)
            if not cand_song:
                continue
                
            cand_artist = cand_song['artist'].lower()
            
            # Apply diversity filter: avoid back-to-back same artist
            if cand_artist in seen_artists and len(recommendations) < 3:
                continue
            seen_artists.add(cand_artist)
            
            # If in harmonic mode, prioritize matching keys
            if mode == "harmonic" and cand_song['key'] != current_song['key']:
                # Allow relative major/minor or circle of fifths (distance 0 or 7)
                key_diff = abs(cand_song['key'] - current_song['key'])
                if key_diff not in [0, 5, 7]:
                    continue
                    
            explanation = self.explain_transition(current_song, cand_song, dist, mode)
            cand_song['algorithm_thinking'] = explanation
            recommendations.append(cand_song)
            
            if len(recommendations) >= count:
                break
                
        # If strict harmonic filter produced fewer than count, top up with nearest
        if len(recommendations) < count:
            for dist, idx in zip(distances, indices):
                if idx == song_id:
                    continue
                cand_song = self.get_song(idx)
                if cand_song and cand_song['id'] not in [r['id'] for r in recommendations]:
                    cand_song['algorithm_thinking'] = self.explain_transition(current_song, cand_song, dist, mode)
                    recommendations.append(cand_song)
                    if len(recommendations) >= count:
                        break

        # Primary next planned song
        primary_next = recommendations[0] if recommendations else None

        return {
            "current_song": current_song,
            "mode": mode,
            "primary_next": primary_next,
            "upcoming_queue": recommendations
        }

    def dijkstra_musical_path(self, start_id: int, target_id: int, k_neighbors: int = 15) -> Dict[str, Any]:
        """
        Dijkstra's Algorithm with Min-Heap Priority Queue.
        Calculates the optimal shortest musical similarity path
        connecting two completely different songs through intermediate tracks!
        """
        start_song = self.get_song(start_id)
        target_song = self.get_song(target_id)
        
        if not start_song or not target_song or self.feature_matrix is None:
            return {"error": "Invalid start or target song ID", "path": []}
            
        if start_id == target_id:
            return {"path": [start_song], "total_distance": 0.0}
            
        print(f"[Dijkstra] Computing musical shortest path from '{start_song['title']}' to '{target_song['title']}'...")
        
        # Priority queue for Dijkstra: (cumulative_distance, current_id)
        pq = MinHeap()
        pq.push(0.0, start_id)
        
        distances = {start_id: 0.0}
        previous: Dict[int, Optional[int]] = {start_id: None}
        visited = set()
        
        # Max search steps to ensure real-time responsiveness (< 200ms)
        max_hops = 1200
        hops = 0
        
        while not pq.is_empty() and hops < max_hops:
            curr_dist, curr_id = pq.pop()
            hops += 1
            
            if curr_id in visited:
                continue
            visited.add(curr_id)
            
            if curr_id == target_id:
                break
                
            # Get semantic neighbors for curr_id
            curr_vec = self.feature_matrix[curr_id]
            dists, neighbors = self.nn_model.kneighbors([curr_vec], n_neighbors=k_neighbors)
            
            # Also check direct distance to target to guide towards destination
            dist_to_target = np.linalg.norm(curr_vec - self.feature_matrix[target_id])
            
            for d, n_id in zip(dists[0], neighbors[0]):
                if n_id == curr_id or n_id in visited:
                    continue
                    
                edge_weight = float(d)
                new_dist = curr_dist + edge_weight
                
                if n_id not in distances or new_dist < distances[n_id]:
                    distances[n_id] = new_dist
                    previous[n_id] = curr_id
                    pq.push(new_dist, n_id)
                    
        # Reconstruct path
        path_ids = []
        curr = target_id
        
        if target_id not in previous:
            # Fallback direct bridge via intermediate nearest neighbors
            mid_dists, mid_idxs = self.nn_model.kneighbors(
                [(self.feature_matrix[start_id] + self.feature_matrix[target_id]) / 2.0], 
                n_neighbors=3
            )
            path_ids = [start_id]
            for m_id in mid_idxs[0]:
                if m_id not in path_ids and m_id != target_id:
                    path_ids.append(int(m_id))
                    break
            path_ids.append(target_id)
        else:
            while curr is not None:
                path_ids.append(curr)
                curr = previous[curr]
            path_ids.reverse()

        path_songs = [self.get_song(sid) for sid in path_ids if self.get_song(sid) is not None]
        
        # Annotate transition thinking for each step along the path
        for i in range(len(path_songs) - 1):
            s1 = path_songs[i]
            s2 = path_songs[i+1]
            dist = float(np.linalg.norm(self.feature_matrix[s1['id']] - self.feature_matrix[s2['id']]))
            s2['transition_from_prev'] = self.explain_transition(s1, s2, dist, "dijkstra_path")

        return {
            "start_song": start_song,
            "target_song": target_song,
            "hops": len(path_songs),
            "path": path_songs
        }

    def get_stats(self) -> Dict[str, Any]:
        """Return dataset & system statistics."""
        if self.df is None:
            return {}
        genre_counts = self.df['playlist_genre'].value_counts().to_dict()
        mood_counts = {MOOD_METADATA[k]["name"]: int(v) for k, v in self.df['mood_cluster'].value_counts().items()}
        return {
            "total_songs": len(self.df),
            "genres": genre_counts,
            "moods": mood_counts,
            "tempo_range": [round(float(self.df['tempo'].min()), 1), round(float(self.df['tempo'].max()), 1)],
            "average_energy": round(float(self.df['energy'].mean()), 2),
            "average_valence": round(float(self.df['valence'].mean()), 2)
        }

# Global singleton instance
engine: Optional[MusicModelEngine] = None

def get_engine() -> MusicModelEngine:
    global engine
    if engine is None:
        engine = MusicModelEngine()
    return engine

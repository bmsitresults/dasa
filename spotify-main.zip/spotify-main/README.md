<div align="center">

# 🎧 Spotify AI DJ & Algorithmic Music Recommender

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![Flask](https://img.shields.io/badge/Flask-3.0+-000000?style=for-the-badge&logo=flask&logoColor=white)](https://flask.palletsprojects.com/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-F7931E?style=for-the-badge&logo=scikit-learn&logoColor=white)](https://scikit-learn.org/)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](LICENSE)

*An intelligent, explainable music player and algorithmic recommendation platform combining Machine Learning (K-Means, Nearest Neighbors) with Graph Algorithms (Dijkstra's Shortest Path) over a 26,000+ track Spotify dataset.*

[Features](#-key-features) • [Algorithms & Data Structures](#-algorithms--data-structures) • [Architecture](#-system-architecture) • [Getting Started](#-getting-started) • [API Documentation](#-api-endpoints)

---

</div>

## 📌 Project Overview

This project bridges **Data Structures & Algorithms (DSA)** with **Applied Machine Learning** to create an interactive, Spotify-inspired web music streaming and discovery application.

Instead of treating recommendations as a "black box", the system features **"The Algorithm's Mind"** — a real-time explainability HUD that renders live radar comparisons, acoustic deltas, and automated reasoning for why each song was chosen. Users can also construct harmonic musical bridges using **Dijkstra's shortest path algorithm** to transition smoothly between any two divergent tracks.

---

## ✨ Key Features

### 1. 🧠 "The Algorithm's Mind" (Explainable AI HUD)
- **Live Vector Alignment:** Real-time parameter radar comparing the current and predicted track across `energy`, `danceability`, `valence`, `tempo`, and `acousticness`.
- **Reasoning Stream:** Dynamic thought chain detailing harmonic key compatibility, BPM variance, and cluster stability.
- **5 Smart DJ Strategies:**
  - 🌊 **Smooth Flow:** Minimizes multidimensional cosine distance for effortless continuity.
  - ⚡ **Energy Boost:** Strategically ramps up acoustic energy (+15–20%) for workouts and party sets.
  - ☕ **Chill Down:** Softens tempo and lowers energy with acoustic/ambient bias.
  - 🎹 **Harmonic Key:** Prioritizes Camelot Wheel compatibility and pitch matching.
  - 🚀 **Adventurous:** Explores neighboring mood clusters with controlled entropy.

### 2. 🧭 Dijkstra's Musical Bridge Pathfinding
- Models the music library as a **weighted directed graph** where vertices represent songs and edge weights represent acoustic distance.
- Uses **Dijkstra's Algorithm with a Min-Heap Priority Queue** to compute the smoothest $K$-step musical transition from any start track to any target track (e.g., journeying from acoustic indie folk to high-energy EDM in 5 smooth steps).

### 3. 🎵 Real-Time Audio Engine
- **iTunes 30s Audio Stream:** Live preview fetching with high-resolution album artwork.
- **Web Audio Melodic Synthesizer:** Built-in procedural harmonic synthesizer fallback guaranteeing uninterrupted audio even when offline.
- **Live Canvas Spectrum Visualizer:** 60 FPS reactive frequency analyzer rendering real-time waveforms and spectrum bars.
- **Dynamic Mood Theming:** Real-time glassmorphism and background ambient glow adapting to the current track's mood cluster.

### 4. 🗂️ Library Exploration & Dynamic Queuing
- Real-time search by title, artist, and genre across **26,000+ tracks**.
- Filter by mood spectrum (Euphoric Party, Chill Acoustic, Melancholy & Deep, Energetic Workout, Late Night Lounge).
- Interactive slide-over **Up Next Queue** drawer with match percentages and instant drag-free playback.
- Track history tracking and favorites management with local persistence.

---

## 🔬 Algorithms & Data Structures

| Technique | Component | Complexity / Specification |
| :--- | :--- | :--- |
| **K-Means Clustering** | Unsupervised Mood & Feature Partitioning | $k=6$ clusters across normalized acoustic vectors; offline fitted |
| **Nearest Neighbors** | Real-time Multi-metric Recommendation | Cosine similarity & Euclidean distance via BallTree / Brute force ($O(\log N)$ query) |
| **Dijkstra's Algorithm** | Song-to-Song Transition Pathfinding | Min-Heap priority queue implementation ($O((V + E) \log V)$) |
| **Adjacency Graph** | Topological Audio Space Representation | Dynamically weighted acoustic distance matrix |
| **Hash Tables / In-Memory Index** | Fast Track Metadata Lookups | $O(1)$ lookups indexed by `song_id` and normalized search tokens |

---

## 🏗️ System Architecture

```mermaid
graph TD
    A[Spotify Dataset 26,000+ Tracks] --> B[Data Preprocessing & Normalization]
    B --> C[StandardScaler & Feature Extraction]
    C --> D[K-Means Clustering - Mood Profiles]
    C --> E[NearestNeighbors Model - Vector Space]
    C --> F[Acoustic Distance Graph Builder]
    
    D --> G[Flask Backend API]
    E --> G
    F --> G
    
    G -->|JSON Endpoints| H[Frontend Web Client]
    
    subgraph Frontend Client
        H --> I[Spotify Dark Glassmorphism UI]
        H --> J[Algorithm's Mind HUD]
        H --> K[Web Audio Visualizer & Player]
        H --> L[Dijkstra Pathfinding Modal]
    end
    
    G --> M[iTunes Search API / Artwork & Audio Previews]
    M --> K
```

---

## 📁 Repository Structure

```text
├── app.py                  # Main Flask REST API & Web Server
├── model_engine.py         # ML Models (KMeans, NearestNeighbors, Dijkstra pathfinder)
├── audio_fetcher.py        # iTunes Audio Preview & High-Res Artwork Fetcher
├── major_project.csv       # Dataset of 26,000+ tracks with Spotify audio features
├── music 1.py              # Standalone Desktop DSA2 GUI implementation (Tkinter)
├── requirements.txt        # Python package dependencies
├── .gitignore              # Git ignore rules
└── static/
    ├── index.html          # Single Page Application layout
    ├── css/
    │   └── style.css       # Premium Spotify dark mode & glassmorphism styling
    └── js/
        └── app.js          # Client-side audio engine, visualizer, & reactive state
```

---

## 🚀 Getting Started

### Prerequisites
- Python 3.9+
- Git

### 1. Clone the Repository
```bash
git clone https://github.com/BurelaBhavan/spotify.git
cd spotify
```

### 2. Set Up Virtual Environment (Recommended)
```bash
# Windows
python -m venv venv
.\venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python app.py
```

Open your browser and navigate to:
```
http://localhost:5000
```

---

## 📡 API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Serves the interactive Spotify web player interface |
| `GET` | `/api/songs` | Fetches filtered/searched songs (`limit`, `query`, `genre`, `mood`) |
| `GET` | `/api/song/<id>` | Retrieves comprehensive track metadata & acoustic vector |
| `GET` | `/api/recommendations/<id>` | Computes next songs based on strategy mode (`flow`, `energy_boost`, etc.) |
| `GET` | `/api/dijkstra` | Computes the shortest acoustic path between `start_id` and `target_id` |
| `GET` | `/api/preview` | Fetches iTunes preview MP3 stream URL & high-resolution artwork |

---

## 🛠️ Built With

- **Backend:** [Python](https://www.python.org/), [Flask](https://flask.palletsprojects.com/), [Pandas](https://pandas.pydata.org/), [NumPy](https://numpy.org/), [Scikit-learn](https://scikit-learn.org/)
- **Frontend:** Vanilla JavaScript (ES6+), Modern Semantic HTML5, Custom CSS3 Design System with CSS Variables
- **Audio & Media:** Web Audio API, HTML5 Audio, Canvas API, Apple iTunes Search API

---

## 👤 Author

- **Burela Bhavan** - [@BurelaBhavan](https://github.com/BurelaBhavan)

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

"""
Music Recommendation System using Data Structures and Algorithms
- Graph (Adjacency List)
- Dijkstra's Algorithm with Priority Queue (Min-Heap)
- BFS for genre clustering
- Hash Maps for O(1) song lookups
- Tkinter GUI for user interaction
"""

import heapq
import json
from collections import defaultdict, deque
from typing import Dict, List, Tuple, Optional
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import math


# ============================================================================
# DATA STRUCTURES: Song Class
# ============================================================================

class Song:
    """Represents a song node in the graph"""
    
    def __init__(self, song_id: int, title: str, artist: str, genre: str, 
                 mood: str, tempo: int, year: int):
        self.id = song_id
        self.title = title
        self.artist = artist
        self.genre = genre
        self.mood = mood
        self.tempo = tempo
        self.year = year
    
    def calculate_similarity(self, other: 'Song') -> float:
        """Calculate similarity score between two songs"""
        score = 0.0
        
        if self.genre != other.genre:
            score += 0.4
        
        if self.mood != other.mood:
            score += 0.3
        
        tempo_diff = abs(self.tempo - other.tempo) / 200.0
        score += min(tempo_diff, 0.2)
        
        if self.artist != other.artist:
            score += 0.1
        
        return round(score, 3)
    
    def __str__(self):
        return f"{self.title} by {self.artist} ({self.genre}, {self.mood})"
    
    def to_dict(self):
        """Convert song to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'title': self.title,
            'artist': self.artist,
            'genre': self.genre,
            'mood': self.mood,
            'tempo': self.tempo,
            'year': self.year
        }


# ============================================================================
# MIN-HEAP PRIORITY QUEUE
# ============================================================================

class MinHeap:
    """Min-Heap implementation using Python's heapq"""
    
    def __init__(self):
        self.heap = []
    
    def push(self, distance: float, song_id: int):
        """Push (distance, song_id) tuple onto heap"""
        heapq.heappush(self.heap, (distance, song_id))
    
    def pop(self) -> Tuple[float, int]:
        """Pop minimum element from heap"""
        return heapq.heappop(self.heap)
    
    def is_empty(self) -> bool:
        """Check if heap is empty"""
        return len(self.heap) == 0


# ============================================================================
# GRAPH DATA STRUCTURE
# ============================================================================

class MusicGraph:
    """Graph representation of songs using Adjacency List"""
    
    def __init__(self):
        self.adjacency_list: Dict[int, List[Tuple[int, float]]] = defaultdict(list)
        self.songs: Dict[int, Song] = {}
        self.next_id = 1
    
    def add_song(self, song: Song) -> None:
        """Add a song node to the graph"""
        if song.id not in self.songs:
            self.songs[song.id] = song
            self.adjacency_list[song.id] = []
            if song.id >= self.next_id:
                self.next_id = song.id + 1
    
    def add_edge(self, song_id1: int, song_id2: int, weight: float) -> None:
        """Add an undirected edge between two songs"""
        if song_id1 in self.songs and song_id2 in self.songs:
            self.adjacency_list[song_id1].append((song_id2, weight))
            self.adjacency_list[song_id2].append((song_id1, weight))
    
    def auto_connect_song(self, song_id: int, threshold: float = 0.8) -> int:
        """Automatically connect a song to all other songs"""
        song = self.songs.get(song_id)
        if not song:
            return 0
        
        connections = 0
        for other_id, other_song in self.songs.items():
            if other_id != song_id:
                existing = any(neighbor_id == other_id 
                             for neighbor_id, _ in self.adjacency_list[song_id])
                
                if not existing:
                    similarity = song.calculate_similarity(other_song)
                    if similarity < threshold:
                        self.add_edge(song_id, other_id, similarity)
                        connections += 1
        
        return connections
    
    def dijkstra(self, start_song_id: int) -> Dict[int, float]:
        """Dijkstra's Algorithm: Find shortest paths from start song"""
        distances = {song_id: float('inf') for song_id in self.songs}
        distances[start_song_id] = 0.0
        
        pq = MinHeap()
        pq.push(0.0, start_song_id)
        
        visited = set()
        
        while not pq.is_empty():
            current_dist, current_id = pq.pop()
            
            if current_id in visited:
                continue
            
            visited.add(current_id)
            
            for neighbor_id, edge_weight in self.adjacency_list[current_id]:
                new_dist = current_dist + edge_weight
                
                if new_dist < distances[neighbor_id]:
                    distances[neighbor_id] = new_dist
                    pq.push(new_dist, neighbor_id)
        
        return distances
    
    def get_top_k_recommendations(self, song_id: int, k: int = 5) -> List[Tuple[Song, float]]:
        """Get top-K most similar songs using Dijkstra's algorithm"""
        distances = self.dijkstra(song_id)
        
        recommendations = []
        for sid, dist in distances.items():
            if sid != song_id and dist != float('inf'):
                recommendations.append((self.songs[sid], dist))
        
        recommendations.sort(key=lambda x: x[1])
        
        return recommendations[:k]
    
    def bfs_genre_cluster(self, start_song_id: int) -> List[Song]:
        """Breadth-First Search: Find all songs in same genre"""
        start_song = self.songs.get(start_song_id)
        if not start_song:
            return []
        
        visited = set()
        queue = deque([start_song_id])
        cluster = []
        
        visited.add(start_song_id)
        
        while queue:
            current_id = queue.popleft()
            current_song = self.songs[current_id]
            
            if current_song.genre == start_song.genre:
                cluster.append(current_song)
            
            for neighbor_id, _ in self.adjacency_list[current_id]:
                if neighbor_id not in visited:
                    visited.add(neighbor_id)
                    queue.append(neighbor_id)
        
        return cluster
    
    def dfs_connected_songs(self, start_song_id: int, max_depth: int = 3) -> List[Song]:
        """Depth-First Search: Explore connected songs"""
        visited = set()
        result = []
        
        def dfs(song_id: int, depth: int):
            if depth > max_depth or song_id in visited:
                return
            
            visited.add(song_id)
            result.append(self.songs[song_id])
            
            neighbors = sorted(self.adjacency_list[song_id], key=lambda x: x[1])
            for neighbor_id, _ in neighbors:
                dfs(neighbor_id, depth + 1)
        
        dfs(start_song_id, 0)
        return result
    
    def get_song(self, song_id: int) -> Optional[Song]:
        """Get song by ID"""
        return self.songs.get(song_id)
    
    def get_all_songs(self) -> List[Song]:
        """Get all songs in the graph"""
        return list(self.songs.values())
    
    def get_connections(self, song_id: int) -> List[Tuple[int, float]]:
        """Get all connections for a song"""
        return self.adjacency_list.get(song_id, [])
    
    def remove_song(self, song_id: int) -> None:
        """Remove a song and all its edges"""
        if song_id in self.songs:
            del self.songs[song_id]
            del self.adjacency_list[song_id]
            
            for sid in self.adjacency_list:
                self.adjacency_list[sid] = [
                    (nid, w) for nid, w in self.adjacency_list[sid] 
                    if nid != song_id
                ]
    
    def save_to_json(self, filename: str) -> None:
        """Save graph to JSON file"""
        data = {
            'songs': [song.to_dict() for song in self.songs.values()],
            'edges': []
        }
        
        seen_edges = set()
        for song_id, neighbors in self.adjacency_list.items():
            for neighbor_id, weight in neighbors:
                edge = tuple(sorted([song_id, neighbor_id]))
                if edge not in seen_edges:
                    seen_edges.add(edge)
                    data['edges'].append({
                        'song1': song_id,
                        'song2': neighbor_id,
                        'weight': weight
                    })
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_from_json(self, filename: str) -> None:
        """Load graph from JSON file"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            for song_data in data['songs']:
                song = Song(**song_data)
                self.add_song(song)
            
            for edge in data['edges']:
                self.add_edge(edge['song1'], edge['song2'], edge['weight'])
        
        except FileNotFoundError:
            pass


# ============================================================================
# TKINTER GUI APPLICATION
# ============================================================================

class MusicRecommendationGUI:
    """Tkinter GUI for the Music Recommendation System"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Music Recommendation System - DSA")
        self.root.geometry("1200x800")
        self.root.configure(bg='#1a1a2e')
        
        self.graph = MusicGraph()
        self._load_sample_data()
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self._configure_styles()
        
        self._create_widgets()
        
        try:
            self.graph.load_from_json('music_graph.json')
            self._refresh_song_list()
        except:
            pass
    
    def _configure_styles(self):
        """Configure ttk styles"""
        self.style.configure('TFrame', background='#1a1a2e')
        self.style.configure('TLabel', background='#1a1a2e', foreground='white', 
                           font=('Arial', 10))
        self.style.configure('Title.TLabel', font=('Arial', 16, 'bold'), 
                           foreground='#4a90e2')
        self.style.configure('TButton', font=('Arial', 10, 'bold'))
    
    def _load_sample_data(self):
        """Load sample songs into the graph"""
        sample_songs = [
            Song(1, "Blinding Lights", "The Weeknd", "Synthpop", "Energetic", 171, 2019),
            Song(2, "Save Your Tears", "The Weeknd", "Synthpop", "Melancholic", 118, 2020),
            Song(3, "Starboy", "The Weeknd", "R&B", "Confident", 186, 2016),
            Song(4, "In Your Eyes", "The Weeknd", "Synthpop", "Romantic", 93, 2020),
            Song(5, "Levitating", "Dua Lipa", "Disco-Pop", "Energetic", 103, 2020),
            Song(6, "Don't Start Now", "Dua Lipa", "Disco-Pop", "Energetic", 124, 2019),
            Song(7, "Physical", "Dua Lipa", "Disco-Pop", "Energetic", 144, 2020),
            Song(8, "Dynamite", "BTS", "Disco-Pop", "Happy", 114, 2020),
            Song(9, "Watermelon Sugar", "Harry Styles", "Pop-Rock", "Happy", 95, 2019),
            Song(10, "Adore You", "Harry Styles", "Pop-Rock", "Romantic", 104, 2019),
            Song(11, "Heat Waves", "Glass Animals", "Indie-Pop", "Melancholic", 80, 2020),
            Song(12, "Circles", "Post Malone", "Pop", "Melancholic", 120, 2019),
            Song(13, "Sunflower", "Post Malone", "Hip-Hop", "Chill", 90, 2018),
            Song(14, "Bad Guy", "Billie Eilish", "Alt-Pop", "Dark", 135, 2019),
            Song(15, "Everything I Wanted", "Billie Eilish", "Alt-Pop", "Melancholic", 133, 2019),
        ]
        
        for song in sample_songs:
            self.graph.add_song(song)
            self.graph.auto_connect_song(song.id)
    
    def _create_widgets(self):
        """Create all GUI widgets"""
        header = ttk.Frame(self.root)
        header.pack(fill='x', padx=20, pady=10)
        
        title = ttk.Label(header, text="Music Recommendation System", 
                         style='Title.TLabel')
        title.pack()
        
        subtitle = ttk.Label(header, 
                            text="Graph-Based DSA • Dijkstra's Algorithm • BFS/DFS",
                            font=('Arial', 9))
        subtitle.pack()
        
        main_container = ttk.Frame(self.root)
        main_container.pack(fill='both', expand=True, padx=20, pady=10)
        
        left_panel = ttk.Frame(main_container)
        left_panel.pack(side='left', fill='both', expand=False, padx=(0, 10))
        
        ttk.Label(left_panel, text="Song Library", 
                 font=('Arial', 12, 'bold')).pack(pady=5)
        
        search_frame = ttk.Frame(left_panel)
        search_frame.pack(fill='x', pady=5)
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self._refresh_song_list())
        
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        search_entry.pack(side='left', fill='x', expand=True)
        
        ttk.Label(search_frame, text="Search").pack(side='left', padx=5)
        
        list_frame = ttk.Frame(left_panel)
        list_frame.pack(fill='both', expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.song_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set,
                                       bg='#16213e', fg='white', 
                                       font=('Arial', 9),
                                       selectmode='single', height=25, width=35)
        self.song_listbox.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.song_listbox.yview)
        
        self.song_listbox.bind('<<ListboxSelect>>', self._on_song_select)
        
        btn_frame = ttk.Frame(left_panel)
        btn_frame.pack(fill='x', pady=10)
        
        ttk.Button(btn_frame, text="Add Song", 
                  command=self._show_add_song_dialog).pack(fill='x', pady=2)
        ttk.Button(btn_frame, text="Delete Song", 
                  command=self._delete_selected_song).pack(fill='x', pady=2)
        ttk.Button(btn_frame, text="Save Data", 
                  command=self._save_data).pack(fill='x', pady=2)
        
        right_panel = ttk.Frame(main_container)
        right_panel.pack(side='right', fill='both', expand=True)
        
        self.notebook = ttk.Notebook(right_panel)
        self.notebook.pack(fill='both', expand=True)
        
        rec_frame = ttk.Frame(self.notebook)
        self.notebook.add(rec_frame, text="Recommendations")
        
        self.rec_text = scrolledtext.ScrolledText(rec_frame, wrap='word', 
                                                  bg='#16213e', fg='white',
                                                  font=('Courier', 10))
        self.rec_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        rec_btn_frame = ttk.Frame(rec_frame)
        rec_btn_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Label(rec_btn_frame, text="Top K:").pack(side='left', padx=5)
        self.k_var = tk.StringVar(value='8')
        ttk.Entry(rec_btn_frame, textvariable=self.k_var, width=5).pack(side='left')
        ttk.Button(rec_btn_frame, text="Refresh Recommendations",
                  command=self._show_recommendations).pack(side='left', padx=10)
        
        conn_frame = ttk.Frame(self.notebook)
        self.notebook.add(conn_frame, text="Graph View")
        
        self.conn_text = scrolledtext.ScrolledText(conn_frame, wrap='word',
                                                   bg='#16213e', fg='white',
                                                   font=('Courier', 10))
        self.conn_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        ttk.Button(conn_frame, text="Show Connections",
                  command=self._show_connections).pack(pady=5)
        
        cluster_frame = ttk.Frame(self.notebook)
        self.notebook.add(cluster_frame, text="Genre Cluster (BFS)")
        
        self.cluster_text = scrolledtext.ScrolledText(cluster_frame, wrap='word',
                                                      bg='#16213e', fg='white',
                                                      font=('Courier', 10))
        self.cluster_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        ttk.Button(cluster_frame, text="Find Genre Cluster",
                  command=self._show_genre_cluster).pack(pady=5)
        
        dfs_frame = ttk.Frame(self.notebook)
        self.notebook.add(dfs_frame, text="DFS Exploration")
        
        self.dfs_text = scrolledtext.ScrolledText(dfs_frame, wrap='word',
                                                  bg='#16213e', fg='white',
                                                  font=('Courier', 10))
        self.dfs_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        dfs_btn_frame = ttk.Frame(dfs_frame)
        dfs_btn_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Label(dfs_btn_frame, text="Max Depth:").pack(side='left', padx=5)
        self.depth_var = tk.StringVar(value='3')
        ttk.Entry(dfs_btn_frame, textvariable=self.depth_var, width=5).pack(side='left')
        ttk.Button(dfs_btn_frame, text="DFS Traverse",
                  command=self._show_dfs).pack(side='left', padx=10)
        
        self._refresh_song_list()
    
    def _refresh_song_list(self):
        """Refresh the song listbox"""
        self.song_listbox.delete(0, tk.END)
        
        search_term = self.search_var.get().lower()
        songs = self.graph.get_all_songs()
        
        songs.sort(key=lambda s: s.title)
        
        for song in songs:
            if (search_term in song.title.lower() or 
                search_term in song.artist.lower()):
                display_text = f"{song.title} - {song.artist}"
                self.song_listbox.insert(tk.END, display_text)
    
    def _get_selected_song_id(self) -> Optional[int]:
        """Get the ID of the currently selected song"""
        selection = self.song_listbox.curselection()
        if not selection:
            return None
        
        index = selection[0]
        song_text = self.song_listbox.get(index)
        
        for song in self.graph.get_all_songs():
            if f"{song.title} - {song.artist}" == song_text:
                return song.id
        
        return None
    
    def _on_song_select(self, event):
        """Handle song selection"""
        self._show_recommendations()
    
    def _show_recommendations(self):
        """Display recommendations using Dijkstra's algorithm"""
        song_id = self._get_selected_song_id()
        if not song_id:
            self.rec_text.delete('1.0', tk.END)
            self.rec_text.insert('1.0', "Please select a song from the library.")
            return
        
        song = self.graph.get_song(song_id)
        
        try:
            k = int(self.k_var.get())
        except ValueError:
            k = 8
        
        recommendations = self.graph.get_top_k_recommendations(song_id, k)
        
        self.rec_text.delete('1.0', tk.END)
        
        output = "=" * 70 + "\n"
        output += f"  RECOMMENDATIONS FOR: {song.title}\n"
        output += f"  Artist: {song.artist}\n"
        output += f"  Genre: {song.genre} | Mood: {song.mood}\n"
        output += "=" * 70 + "\n"
        output += "  Using Dijkstra's Algorithm - Shortest Path in Graph\n"
        output += "=" * 70 + "\n\n"
        
        if recommendations:
            output += f"Top {len(recommendations)} Similar Songs:\n"
            output += "=" * 70 + "\n\n"
            
            for i, (rec_song, similarity) in enumerate(recommendations, 1):
                output += f"#{i}. {rec_song.title}\n"
                output += f"    Artist: {rec_song.artist}\n"
                output += f"    Genre: {rec_song.genre} | Mood: {rec_song.mood} | Tempo: {rec_song.tempo} BPM\n"
                stars = '★' * min(5, int((0.8 - similarity) * 10))
                output += f"    Similarity Score: {similarity:.3f} ({stars})\n"
                output += f"    {'-' * 66}\n\n"
        else:
            output += "No recommendations found. Try connecting more songs!\n"
        
        self.rec_text.insert('1.0', output)
    
    def _show_connections(self):
        """Display graph connections for selected song"""
        song_id = self._get_selected_song_id()
        if not song_id:
            self.conn_text.delete('1.0', tk.END)
            self.conn_text.insert('1.0', "Please select a song from the library.")
            return
        
        song = self.graph.get_song(song_id)
        connections = self.graph.get_connections(song_id)
        
        connections.sort(key=lambda x: x[1])
        
        self.conn_text.delete('1.0', tk.END)
        
        output = "=" * 70 + "\n"
        output += f"  GRAPH CONNECTIONS FOR: {song.title}\n"
        output += "=" * 70 + "\n"
        output += f"  Total Edges: {len(connections)}\n"
        output += "=" * 70 + "\n\n"
        
        if connections:
            output += "Connected Songs (Edges in Adjacency List):\n"
            output += "=" * 70 + "\n\n"
            
            for i, (neighbor_id, weight) in enumerate(connections, 1):
                neighbor = self.graph.get_song(neighbor_id)
                output += f"{i}. {neighbor.title} - {neighbor.artist}\n"
                output += f"   Weight: {weight:.3f} | Genre: {neighbor.genre} | Mood: {neighbor.mood}\n"
                output += f"   {'-' * 66}\n"
        else:
            output += "No connections found.\n"
        
        self.conn_text.insert('1.0', output)
    
    def _show_genre_cluster(self):
        """Display genre cluster using BFS"""
        song_id = self._get_selected_song_id()
        if not song_id:
            self.cluster_text.delete('1.0', tk.END)
            self.cluster_text.insert('1.0', "Please select a song from the library.")
            return
        
        song = self.graph.get_song(song_id)
        cluster = self.graph.bfs_genre_cluster(song_id)
        
        self.cluster_text.delete('1.0', tk.END)
        
        output = "=" * 70 + "\n"
        output += f"  GENRE CLUSTER FOR: {song.title}\n"
        output += f"  Genre: {song.genre}\n"
        output += "=" * 70 + "\n"
        output += "  Algorithm: Breadth-First Search (BFS)\n"
        output += f"  Cluster Size: {len(cluster)}\n"
        output += "=" * 70 + "\n\n"
        
        if cluster:
            output += f"All songs in '{song.genre}' genre:\n"
            output += "=" * 70 + "\n\n"
            
            for i, cluster_song in enumerate(cluster, 1):
                output += f"{i}. {cluster_song.title} - {cluster_song.artist}\n"
                output += f"   Mood: {cluster_song.mood} | Tempo: {cluster_song.tempo} BPM | Year: {cluster_song.year}\n"
                output += f"   {'-' * 66}\n"
        else:
            output += "No songs found in this genre cluster.\n"
        
        self.cluster_text.insert('1.0', output)
    
    def _show_dfs(self):
        """Display DFS traversal"""
        song_id = self._get_selected_song_id()
        if not song_id:
            self.dfs_text.delete('1.0', tk.END)
            self.dfs_text.insert('1.0', "Please select a song from the library.")
            return
        
        try:
            max_depth = int(self.depth_var.get())
        except ValueError:
            max_depth = 3
        
        song = self.graph.get_song(song_id)
        connected_songs = self.graph.dfs_connected_songs(song_id, max_depth)
        
        self.dfs_text.delete('1.0', tk.END)
        
        output = "=" * 70 + "\n"
        output += f"  DFS TRAVERSAL FROM: {song.title}\n"
        output += "=" * 70 + "\n"
        output += "  Algorithm: Depth-First Search (DFS)\n"
        output += f"  Max Depth: {max_depth}\n"
        output += f"  Songs Found: {len(connected_songs)}\n"
        output += "=" * 70 + "\n\n"
        
        if connected_songs:
            output += "DFS Traversal Order:\n"
            output += "=" * 70 + "\n\n"
            
            for i, dfs_song in enumerate(connected_songs):
                output += f"{i}. {dfs_song.title} - {dfs_song.artist}\n"
                output += f"   Genre: {dfs_song.genre} | Mood: {dfs_song.mood} | Tempo: {dfs_song.tempo} BPM\n"
                output += f"   {'-' * 66}\n"
        else:
            output += "No connected songs found.\n"
        
        self.dfs_text.insert('1.0', output)
    
    def _show_add_song_dialog(self):
        """Show dialog to add a new song"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add New Song")
        dialog.geometry("400x500")
        dialog.configure(bg='#1a1a2e')
        dialog.transient(self.root)
        dialog.grab_set()
        
        ttk.Label(dialog, text="Add New Song", 
                 font=('Arial', 14, 'bold')).pack(pady=10)
        
        form = ttk.Frame(dialog)
        form.pack(fill='both', expand=True, padx=20, pady=10)
        
        fields = {}
        
        ttk.Label(form, text="Song Title *").grid(row=0, column=0, sticky='w', pady=5)
        fields['title'] = ttk.Entry(form, width=30)
        fields['title'].grid(row=0, column=1, pady=5)
        
        ttk.Label(form, text="Artist *").grid(row=1, column=0, sticky='w', pady=5)
        fields['artist'] = ttk.Entry(form, width=30)
        fields['artist'].grid(row=1, column=1, pady=5)
        
        ttk.Label(form, text="Genre").grid(row=2, column=0, sticky='w', pady=5)
        genres = ['Pop', 'Rock', 'Hip-Hop', 'R&B', 'Synthpop', 'Disco-Pop', 
                 'Pop-Rock', 'Indie-Pop', 'Alt-Pop', 'Electronic', 'Jazz', 
                 'Classical', 'Country', 'Reggae']
        fields['genre'] = ttk.Combobox(form, values=genres, width=28)
        fields['genre'].set('Pop')
        fields['genre'].grid(row=2, column=1, pady=5)
        
        ttk.Label(form, text="Mood").grid(row=3, column=0, sticky='w', pady=5)
        moods = ['Happy', 'Energetic', 'Melancholic', 'Romantic', 'Confident', 
                'Chill', 'Dark', 'Uplifting', 'Aggressive', 'Peaceful']
        fields['mood'] = ttk.Combobox(form, values=moods, width=28)
        fields['mood'].set('Happy')
        fields['mood'].grid(row=3, column=1, pady=5)
        
        ttk.Label(form, text="Tempo (BPM)").grid(row=4, column=0, sticky='w', pady=5)
        fields['tempo'] = ttk.Entry(form, width=30)
        fields['tempo'].insert(0, '120')
        fields['tempo'].grid(row=4, column=1, pady=5)
        
        ttk.Label(form, text="Year").grid(row=5, column=0, sticky='w', pady=5)
        fields['year'] = ttk.Entry(form, width=30)
        fields['year'].insert(0, '2024')
        fields['year'].grid(row=5, column=1, pady=5)
        
        info_text = tk.Text(form, height=6, width=40, bg='#16213e', fg='white',
                           font=('Arial', 8), wrap='word')
        info_text.grid(row=6, column=0, columnspan=2, pady=10)
        info_text.insert('1.0', 
            "How it works:\n\n"
            "When you add a song, it becomes a new node in the graph. "
            "The system automatically calculates similarity scores with all "
            "existing songs and creates weighted edges. Similarity is based on:\n"
            "Genre (40%), Mood (30%), Tempo (20%), Artist (10%)")
        info_text.config(state='disabled')
        
        def save_song():
            title = fields['title'].get().strip()
            artist = fields['artist'].get().strip()
            
            if not title or not artist:
                messagebox.showerror("Error", "Please enter title and artist!")
                return
            
            try:
                tempo = int(fields['tempo'].get())
                year = int(fields['year'].get())
            except ValueError:
                messagebox.showerror("Error", "Tempo and Year must be numbers!")
                return
            
            song = Song(
                song_id=self.graph.next_id,
                title=title,
                artist=artist,
                genre=fields['genre'].get(),
                mood=fields['mood'].get(),
                tempo=tempo,
                year=year
            )
            
            self.graph.add_song(song)
            connections = self.graph.auto_connect_song(song.id)
            
            messagebox.showinfo("Success", 
                f"Song added successfully!\n\n"
                f"Created {connections} connections in the graph.")
            
            self._refresh_song_list()
            dialog.destroy()
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Add Song", 
                  command=save_song).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Cancel", 
                  command=dialog.destroy).pack(side='left', padx=5)
    
    def _delete_selected_song(self):
        """Delete the selected song"""
        song_id = self._get_selected_song_id()
        if not song_id:
            messagebox.showwarning("Warning", "Please select a song to delete.")
            return
        
        song = self.graph.get_song(song_id)
        
        if messagebox.askyesno("Confirm Delete", 
                              f"Are you sure you want to delete:\n\n"
                              f"{song.title} by {song.artist}?"):
            self.graph.remove_song(song_id)
            self._refresh_song_list()
            
            self.rec_text.delete('1.0', tk.END)
            self.conn_text.delete('1.0', tk.END)
            self.cluster_text.delete('1.0', tk.END)
            self.dfs_text.delete('1.0', tk.END)
            
            messagebox.showinfo("Success", "Song deleted successfully!")
    
    def _save_data(self):
        """Save graph data to JSON"""
        try:
            self.graph.save_to_json('music_graph.json')
            messagebox.showinfo("Success", 
                              "Data saved to music_graph.json successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save data:\n{str(e)}")


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point for the application"""
    root = tk.Tk()
    app = MusicRecommendationGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()


# ============================================================================
# DOCUMENTATION
# ============================================================================

"""
ALGORITHM COMPLEXITY ANALYSIS
===============================

1. DIJKSTRA'S ALGORITHM (Shortest Path)
   Time Complexity: O((V + E) log V)
   Space Complexity: O(V)

2. BREADTH-FIRST SEARCH (BFS)
   Time Complexity: O(V + E)
   Space Complexity: O(V)

3. DEPTH-FIRST SEARCH (DFS)
   Time Complexity: O(V + E)
   Space Complexity: O(V)

4. MIN-HEAP OPERATIONS
   Push: O(log n)
   Pop: O(log n)

5. HASH MAP OPERATIONS
   Get/Set/Delete: O(1) average

6. GRAPH OPERATIONS
   Add Vertex: O(1)
   Add Edge: O(1)
   Remove Vertex: O(V + E)

DATA STRUCTURES USED
====================

1. Graph (Adjacency List)
2. Hash Map (Dictionary)
3. Min-Heap (Priority Queue)
4. Set (Visited Tracking)
5. Queue (Deque for BFS)

SIMILARITY CALCULATION
======================

Similarity Score = Genre_Score + Mood_Score + Tempo_Score + Artist_Score

Where:
  Genre_Score  = 0.4 if different, 0 if same
  Mood_Score   = 0.3 if different, 0 if same
  Tempo_Score  = min(|tempo1 - tempo2| / 200, 0.2)
  Artist_Score = 0.1 if different, 0 if same

Range: [0, 1] where 0 = identical, 1 = completely different

USAGE INSTRUCTIONS
==================

1. Run: python music_recommendation_system.py
2. Select a song from the library
3. View recommendations in different tabs
4. Add new songs using the Add Song button
5. Save data with the Save Data button

FEATURES
========

- Graph-based recommendation system
- Dijkstra's algorithm for similarity
- Min-heap priority queue
- BFS for genre clustering
- DFS for exploration
- Hash maps for O(1) lookups
- Dynamic graph
- Persistent JSON storage
- Modern Tkinter GUI
"""

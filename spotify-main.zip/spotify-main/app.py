"""
Flask Web Application for Spotify-like Smart DJ Music Interface
Provides REST API for search, ML-based next-song recommendations,
real-time audio previews, and Dijkstra graph pathfinding.
"""

from flask import Flask, request, jsonify, send_from_directory
import os
import sys

from model_engine import get_engine, MOOD_METADATA
from audio_fetcher import get_audio_and_artwork

# Ensure static folder exists
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
os.makedirs(STATIC_DIR, exist_ok=True)

app = Flask(__name__, static_folder=STATIC_DIR)

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

# Initialize engine on startup
print("[Server] Initializing Music Recommendation Engine...")
engine = get_engine()
print("[Server] Engine ready! Serving 26,000+ tracks.")

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")

@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory(STATIC_DIR, filename)

@app.route("/api/stats", methods=["GET"])
def api_stats():
    stats = engine.get_stats()
    return jsonify(stats)

@app.route("/api/moods", methods=["GET"])
def api_moods():
    moods = []
    for k, v in MOOD_METADATA.items():
        moods.append({
            "id": k,
            "name": v["name"],
            "description": v["description"],
            "color": v["color"],
            "icon": v["icon"]
        })
    return jsonify(moods)

@app.route("/api/songs", methods=["GET"])
def api_songs():
    query = request.args.get("query", "").strip()
    genre = request.args.get("genre", "").strip()
    mood_str = request.args.get("mood", "").strip()
    limit = min(int(request.args.get("limit", 25)), 100)
    offset = max(int(request.args.get("offset", 0)), 0)
    
    mood_cluster = None
    if mood_str and mood_str.isdigit():
        mood_cluster = int(mood_str)
        
    results = engine.search_songs(
        query=query,
        genre=genre,
        mood_cluster=mood_cluster,
        limit=limit,
        offset=offset
    )
    return jsonify(results)

@app.route("/api/song/<int:song_id>", methods=["GET"])
def api_song(song_id):
    song = engine.get_song(song_id)
    if not song:
        return jsonify({"error": "Song not found"}), 404
    return jsonify(song)

@app.route("/api/preview", methods=["GET"])
def api_preview():
    song_id = request.args.get("id")
    if song_id and song_id.isdigit():
        song = engine.get_song(int(song_id))
        if not song:
            return jsonify({"error": "Song not found"}), 404
        title = song["title"]
        artist = song["artist"]
    else:
        title = request.args.get("title", "")
        artist = request.args.get("artist", "")
        
    if not title or not artist:
        return jsonify({"error": "Title and artist required"}), 400
        
    audio_info = get_audio_and_artwork(title, artist)
    return jsonify(audio_info)

@app.route("/api/recommendations/<int:song_id>", methods=["GET"])
def api_recommendations(song_id):
    mode = request.args.get("mode", "flow").strip()
    count = min(int(request.args.get("count", 10)), 30)
    
    recs = engine.get_next_recommendations(song_id, mode=mode, count=count)
    if not recs.get("current_song"):
        return jsonify({"error": "Song not found"}), 404
        
    return jsonify(recs)

@app.route("/api/dijkstra", methods=["GET"])
def api_dijkstra():
    start_id = request.args.get("start_id")
    target_id = request.args.get("target_id")
    
    if not start_id or not target_id or not start_id.isdigit() or not target_id.isdigit():
        return jsonify({"error": "start_id and target_id are required integers"}), 400
        
    path_data = engine.dijkstra_musical_path(int(start_id), int(target_id))
    return jsonify(path_data)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"[Server] Running Spotify Smart DJ Web Interface on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)

/**
 * Spotify AI DJ • Front-end Client & Audio Engine
 * Features:
 * - Real-time audio playback (iTunes preview + Web Audio Synthesizer fallback)
 * - Dynamic Algorithmic Brain reasoning display & parameter radar
 * - Continuous AI Flow Autoplay (designs next track according to current song's mood)
 * - Real-time Canvas Frequency Visualizer
 * - Instant search & filtering across 26,000+ tracks
 * - Dijkstra shortest musical path finding (DSA 2)
 */

// ============================================================================
// APPLICATION STATE
// ============================================================================
const state = {
  currentSong: null,
  isPlaying: false,
  currentMode: 'flow',
  autoplay: true,
  currentGenre: '',
  currentMood: -1,
  searchQuery: '',
  upcomingQueue: [],
  history: [],
  favorites: new Set(JSON.parse(localStorage.getItem('spotify_favs') || '[]')),
  audioContext: null,
  analyser: null,
  audioSource: null,
  isVisualizerRunning: false,
  synthInterval: null,
  isUsingSynth: false,
  trackCache: new Map()
};

// DOM Elements
const audio = document.getElementById('nativeAudioPlayer');
const btnPlayPause = document.getElementById('btnPlayPause');
const heroPlayBtn = document.getElementById('heroPlayBtn');
const playPauseIcon = document.getElementById('playPauseIcon');
const heroPlayIcon = document.getElementById('heroPlayIcon');
const progressBarContainer = document.getElementById('progressBarContainer');
const progressBarFill = document.getElementById('progressBarFill');
const currentTimeLabel = document.getElementById('currentTimeLabel');
const totalDurationLabel = document.getElementById('totalDurationLabel');
const volumeSlider = document.getElementById('volumeSlider');
const btnMute = document.getElementById('btnMute');
const btnNext = document.getElementById('btnNext');
const btnPrev = document.getElementById('btnPrev');
const btnAutoplay = document.getElementById('btnAutoplay');
const searchInput = document.getElementById('searchInput');
const searchClearBtn = document.getElementById('searchClearBtn');
const trackTableBody = document.getElementById('trackTableBody');
const heroBanner = document.getElementById('heroBanner');
const queueDrawer = document.getElementById('queueDrawer');
const toggleQueueBtn = document.getElementById('toggleQueueBtn');
const closeQueueBtn = document.getElementById('closeQueueBtn');
const queueList = document.getElementById('queueList');
const toastMsg = document.getElementById('toastMsg');
const dijkstraModal = document.getElementById('dijkstraModal');
const openDijkstraModalBtn = document.getElementById('openDijkstraModalBtn');
const closeDijkstraModalBtn = document.getElementById('closeDijkstraModalBtn');
const btnCalculatePath = document.getElementById('btnCalculatePath');
const dijkstraStartSelect = document.getElementById('dijkstraStartSelect');
const dijkstraTargetSelect = document.getElementById('dijkstraTargetSelect');
const dijkstraResultsArea = document.getElementById('dijkstraResultsArea');
const pathStepsContainer = document.getElementById('pathStepsContainer');
const pathHopsSummary = document.getElementById('pathHopsSummary');
const canvas = document.getElementById('audioVisualizer');
const canvasCtx = canvas.getContext('2d');

// Default fallback album art
const DEFAULT_ARTWORK = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80";

// ============================================================================
// INITIALIZATION
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  loadInitialSongs();
  setupVisualizer();
  updateFavoritesCount();
});

function setupEventListeners() {
  // Play/Pause
  btnPlayPause.addEventListener('click', togglePlayPause);
  heroPlayBtn.addEventListener('click', togglePlayPause);

  // Next / Prev
  btnNext.addEventListener('click', () => playNextSong(true));
  btnPrev.addEventListener('click', playPrevSong);

  // Autoplay toggle
  btnAutoplay.addEventListener('click', () => {
    state.autoplay = !state.autoplay;
    btnAutoplay.classList.toggle('active', state.autoplay);
    showToast(`Continuous AI Flow: ${state.autoplay ? 'ON' : 'OFF'}`);
  });

  // Audio element events
  audio.addEventListener('timeupdate', updateTimeline);
  audio.addEventListener('ended', onTrackEnded);
  audio.addEventListener('play', () => setPlayingUI(true));
  audio.addEventListener('pause', () => setPlayingUI(false));
  audio.addEventListener('error', handleAudioPlaybackError);

  // Timeline seeking
  progressBarContainer.addEventListener('click', handleSeek);

  // Volume
  volumeSlider.addEventListener('input', (e) => {
    audio.volume = parseFloat(e.target.value);
  });
  btnMute.addEventListener('click', () => {
    audio.muted = !audio.muted;
    btnMute.style.color = audio.muted ? '#ef4444' : 'var(--text-sub)';
  });

  // Search input with debounce
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    state.searchQuery = query;
    searchClearBtn.style.display = query ? 'block' : 'none';
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      fetchAndRenderTracks();
    }, 280);
  });

  searchClearBtn.addEventListener('click', () => {
    searchInput.value = '';
    state.searchQuery = '';
    searchClearBtn.style.display = 'none';
    fetchAndRenderTracks();
  });

  // Keyboard shortcut: Ctrl + K / Spacebar
  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && e.target.tagName !== 'INPUT') {
      e.preventDefault();
      togglePlayPause();
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      searchInput.focus();
    }
  });

  // Strategy Mode Selector Tabs (Smooth flow, Energy boost, Chill, etc.)
  document.querySelectorAll('#strategyTabs .strategy-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#strategyTabs .strategy-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentMode = btn.dataset.mode;
      document.getElementById('aiStatusText').textContent = `AI DJ: ${btn.textContent.trim()}`;
      showToast(`Strategy switched to: ${btn.textContent.trim()}`);
      if (state.currentSong) {
        fetchRecommendations(state.currentSong.id);
      }
    });
  });

  // Genre filter pills
  document.querySelectorAll('#genreFilterPills .genre-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#genreFilterPills .genre-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      state.currentGenre = pill.dataset.genre;
      fetchAndRenderTracks();
    });
  });

  // Sidebar Mood list items
  document.querySelectorAll('#sidebarMoodList .mood-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('#sidebarMoodList .mood-item').forEach(m => m.classList.remove('active'));
      item.classList.add('active');
      state.currentMood = parseInt(item.dataset.mood, 10);
      fetchAndRenderTracks();
    });
  });

  // Queue drawer toggle
  toggleQueueBtn.addEventListener('click', () => {
    queueDrawer.classList.toggle('open');
    if (queueDrawer.classList.contains('open') && state.currentSong) {
      if (state.upcomingQueue.length === 0) {
        fetchRecommendations(state.currentSong.id);
      } else {
        renderQueueList(state.upcomingQueue);
      }
    }
  });
  closeQueueBtn.addEventListener('click', () => queueDrawer.classList.remove('open'));
  document.getElementById('navQueue').addEventListener('click', () => {
    queueDrawer.classList.toggle('open');
    if (queueDrawer.classList.contains('open') && state.currentSong) {
      if (state.upcomingQueue.length === 0) {
        fetchRecommendations(state.currentSong.id);
      } else {
        renderQueueList(state.upcomingQueue);
      }
    }
  });

  // Next Track Preview Box click (in Algorithm's Mind HUD)
  const nextTrackBox = document.getElementById('nextTrackPreviewBox');
  if (nextTrackBox) {
    nextTrackBox.addEventListener('click', () => {
      if (state.nextPredictedSong) {
        showToast(`AI DJ: Transitioning to ${state.nextPredictedSong.title}`);
        loadSong(state.nextPredictedSong, true);
      } else {
        playNextSong(true);
      }
    });
  }

  const btnPlayNextPredicted = document.getElementById('btnPlayNextPredicted');
  if (btnPlayNextPredicted) {
    btnPlayNextPredicted.addEventListener('click', (e) => {
      e.stopPropagation();
      if (state.nextPredictedSong) {
        showToast(`AI DJ: Transitioning to ${state.nextPredictedSong.title}`);
        loadSong(state.nextPredictedSong, true);
      } else {
        playNextSong(true);
      }
    });
  }

  // Hero shortcuts
  document.getElementById('heroBrainBtn').addEventListener('click', () => {
    document.getElementById('brainContainer').scrollIntoView({ behavior: 'smooth' });
  });

  document.getElementById('heroDijkstraBtn').addEventListener('click', () => {
    openDijkstraModalWithCurrent();
  });

  // Dijkstra modal handlers
  openDijkstraModalBtn.addEventListener('click', openDijkstraModalWithCurrent);
  document.getElementById('navDijkstra').addEventListener('click', openDijkstraModalWithCurrent);
  closeDijkstraModalBtn.addEventListener('click', () => dijkstraModal.classList.remove('open'));
  dijkstraModal.addEventListener('click', (e) => {
    if (e.target === dijkstraModal) dijkstraModal.classList.remove('open');
  });
  btnCalculatePath.addEventListener('click', runDijkstraPathfinding);

  // Favorites filter
  document.getElementById('navFavorites').addEventListener('click', () => {
    renderFavoritesView();
  });

  // Home filter
  document.getElementById('navHome').addEventListener('click', () => {
    state.currentGenre = '';
    state.currentMood = -1;
    state.searchQuery = '';
    searchInput.value = '';
    searchClearBtn.style.display = 'none';
    document.querySelectorAll('#genreFilterPills .genre-pill').forEach(p => p.classList.toggle('active', p.dataset.genre === ''));
    document.querySelectorAll('#sidebarMoodList .mood-item').forEach(m => m.classList.toggle('active', m.dataset.mood === '-1'));
    fetchAndRenderTracks();
  });

  // Like button in player
  document.getElementById('playerLikeBtn').addEventListener('click', () => {
    if (state.currentSong) {
      toggleFavorite(state.currentSong.id);
      updatePlayerLikeBtn();
    }
  });
}

// ============================================================================
// DATA FETCHING & RENDERING
// ============================================================================
async function loadInitialSongs() {
  try {
    const res = await fetch('/api/songs?limit=25');
    const data = await res.json();
    if (data.songs && data.songs.length > 0) {
      renderTrackTable(data.songs);
      // Automatically load the first track into the player as featured
      loadSong(data.songs[0], false);
      populateDijkstraDropdowns(data.songs);
    }
  } catch (err) {
    console.error("Error loading songs:", err);
  }
}

async function fetchAndRenderTracks() {
  try {
    let url = `/api/songs?limit=30`;
    if (state.searchQuery) url += `&query=${encodeURIComponent(state.searchQuery)}`;
    if (state.currentGenre) url += `&genre=${encodeURIComponent(state.currentGenre)}`;
    if (state.currentMood >= 0) url += `&mood=${state.currentMood}`;

    const res = await fetch(url);
    const data = await res.json();
    renderTrackTable(data.songs || []);

    const countLabel = document.getElementById('trackCountBadge');
    countLabel.textContent = `Found ${data.total || 0} tracks`;

    const heading = document.getElementById('sectionHeading');
    if (state.searchQuery) {
      heading.textContent = `Search results for "${state.searchQuery}"`;
    } else if (state.currentGenre) {
      heading.textContent = `${state.currentGenre.toUpperCase()} Tracks`;
    } else if (state.currentMood >= 0) {
      heading.textContent = `Mood Station`;
    } else {
      heading.textContent = `Recommended Library Tracks`;
    }
  } catch (err) {
    console.error("Error fetching tracks:", err);
  }
}

function renderTrackTable(songs) {
  trackTableBody.innerHTML = '';
  if (!songs || songs.length === 0) {
    trackTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:40px; color:var(--text-muted)">No matching tracks found. Try a different query.</td></tr>`;
    return;
  }

  songs.forEach((song, idx) => {
    state.trackCache.set(song.id, song);
    const tr = document.createElement('tr');
    tr.className = `track-row ${state.currentSong && state.currentSong.id === song.id ? 'playing' : ''}`;
    tr.id = `trackRow-${song.id}`;

    const isLiked = state.favorites.has(song.id);
    const isThisPlaying = state.isPlaying && state.currentSong && state.currentSong.id === song.id;

    tr.innerHTML = `
      <td class="track-index-cell">
        <span class="row-num">${isThisPlaying ? renderPlayingBars() : (idx + 1)}</span>
        <span class="row-play-icon">▶</span>
      </td>
      <td>
        <div class="track-meta-cell">
          <img src="${DEFAULT_ARTWORK}" data-songid="${song.id}" class="track-mini-art" alt="Art">
          <div class="track-text-group">
            <div class="track-title-text">${escapeHtml(song.title)}</div>
            <div class="track-artist-text">${escapeHtml(song.artist)} • ${escapeHtml(song.album || 'Single')}</div>
          </div>
        </div>
      </td>
      <td>
        <span class="mood-badge-table" style="border-color:${song.mood_color}55; color:${song.mood_color}">
          <span>${song.mood_icon}</span>
          <span>${song.mood_name}</span>
        </span>
      </td>
      <td>
        <div class="feature-bars-inline">
          <div class="mini-param-row">
            <span>NRG</span>
            <div class="mini-param-track"><div class="mini-param-fill-nrg" style="width:${song.energy * 100}%"></div></div>
            <span>${Math.round(song.energy * 100)}%</span>
          </div>
          <div class="mini-param-row">
            <span>VAL</span>
            <div class="mini-param-track"><div class="mini-param-fill-val" style="width:${song.valence * 100}%"></div></div>
            <span>${Math.round(song.valence * 100)}%</span>
          </div>
        </div>
      </td>
      <td style="text-align:right">
        <span class="track-duration-text">${song.duration_formatted}</span>
      </td>
      <td>
        <button class="like-btn ${isLiked ? 'liked' : ''}" data-likeid="${song.id}" title="Favorite">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
        </button>
      </td>
    `;

    // Row click -> Play song
    tr.addEventListener('click', (e) => {
      if (e.target.closest('.like-btn')) return;
      loadSong(song, true);
    });

    // Like button click
    const likeBtn = tr.querySelector('.like-btn');
    likeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFavorite(song.id);
      likeBtn.classList.toggle('liked', state.favorites.has(song.id));
    });

    trackTableBody.appendChild(tr);

    // Lazy load artwork preview
    fetchArtworkThumbnail(song.id, tr.querySelector('.track-mini-art'));
  });
}

function renderPlayingBars() {
  return `<span class="playing-bars"><span class="playing-bar"></span><span class="playing-bar"></span><span class="playing-bar"></span><span class="playing-bar"></span></span>`;
}

// ============================================================================
// AUDIO PLAYBACK & ALGORITHM FLOW
// ============================================================================
async function loadSong(song, autoPlay = true) {
  if (!song) return;

  state.currentSong = song;
  state.history.push(song);

  // Update dynamic mood colors on UI
  setDynamicMoodColor(song.mood_color);

  // Update Hero Banner
  document.getElementById('heroTitle').textContent = song.title;
  document.getElementById('heroArtist').textContent = song.artist;
  document.getElementById('heroAlbum').textContent = song.album || 'Single';
  document.getElementById('heroGenre').textContent = `${song.genre} / ${song.subgenre || song.genre}`;
  document.getElementById('heroBPM').textContent = `${song.tempo} BPM`;
  document.getElementById('heroDuration').textContent = song.duration_formatted;
  document.getElementById('heroMoodIcon').textContent = song.mood_icon;
  document.getElementById('heroMoodText').textContent = song.mood_name;

  // Update Bottom Player Bar
  document.getElementById('playerTitle').textContent = song.title;
  document.getElementById('playerArtist').textContent = song.artist;
  document.getElementById('playerMood').textContent = `${song.mood_icon} ${song.mood_name}`;
  document.getElementById('totalDurationLabel').textContent = "0:30"; // Standard preview length
  updatePlayerLikeBtn();

  // Highlight active row in table
  document.querySelectorAll('.track-row').forEach(row => {
    row.classList.remove('playing');
    const numEl = row.querySelector('.row-num');
    if (numEl && numEl.dataset.idx) numEl.textContent = numEl.dataset.idx;
  });
  const activeRow = document.getElementById(`trackRow-${song.id}`);
  if (activeRow) {
    activeRow.classList.add('playing');
    const numEl = activeRow.querySelector('.row-num');
    if (numEl) numEl.innerHTML = renderPlayingBars();
  }

  // IMMEDIATELY compute recommendations and fill up the upcoming queue (in parallel)
  fetchRecommendations(song.id);

  // Fetch audio preview and play without blocking the UI
  fetchAudioAndPlay(song, autoPlay);
}

async function fetchAudioAndPlay(song, autoPlay) {
  try {
    const previewRes = await fetch(`/api/preview?id=${song.id}`);
    const previewData = await previewRes.json();

    if (previewData.artwork_url) {
      document.getElementById('heroArt').src = previewData.artwork_url;
      document.getElementById('playerArt').src = previewData.artwork_url;
    }

    if (previewData.preview_url) {
      stopSynthesizer();
      state.isUsingSynth = false;
      audio.src = previewData.preview_url;
      if (autoPlay) {
        startAudioPlayback();
      }
    } else {
      console.log(`[Playback] No iTunes preview stream for '${song.title}'. Activating Web Audio synthesizer.`);
      playWithSynthesizer(song, autoPlay);
    }
  } catch (err) {
    console.warn("Error fetching audio preview, falling back to synthesizer:", err);
    playWithSynthesizer(song, autoPlay);
  }
}

function startAudioPlayback() {
  initAudioContext();
  audio.play().then(() => {
    state.isPlaying = true;
    setPlayingUI(true);
    startVisualizer();
  }).catch(err => {
    console.warn("Autoplay was prevented by browser policy, awaiting user gesture:", err);
    setPlayingUI(false);
  });
}

function togglePlayPause() {
  if (!state.currentSong) return;

  initAudioContext();

  if (state.isUsingSynth) {
    if (state.isPlaying) {
      stopSynthesizer();
      state.isPlaying = false;
      setPlayingUI(false);
    } else {
      playWithSynthesizer(state.currentSong, true);
    }
    return;
  }

  if (audio.paused) {
    audio.play().then(() => {
      state.isPlaying = true;
      setPlayingUI(true);
      startVisualizer();
    }).catch(err => console.log("Play failed:", err));
  } else {
    audio.pause();
    state.isPlaying = false;
    setPlayingUI(false);
  }
}

function setPlayingUI(playing) {
  state.isPlaying = playing;
  const playSvg = '<polygon points="5 3 19 12 5 21 5 3"></polygon>';
  const pauseSvg = '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';

  playPauseIcon.innerHTML = playing ? pauseSvg : playSvg;
  heroPlayIcon.innerHTML = playing ? pauseSvg : playSvg;
  document.getElementById('heroStatusBadge').textContent = playing ? 'NOW PLAYING' : 'PAUSED';
}

function onTrackEnded() {
  if (state.autoplay) {
    console.log("[Autoplay] Track ended. Transitioning to next song designed by algorithm...");
    playNextSong(false);
  } else {
    setPlayingUI(false);
  }
}

function playNextSong(userTriggered = false) {
  if (state.upcomingQueue && state.upcomingQueue.length > 0) {
    const nextSong = state.upcomingQueue.shift();
    if (userTriggered) {
      showToast(`AI DJ: Transitioning to ${nextSong.title}`);
    }
    renderQueueList(state.upcomingQueue);
    loadSong(nextSong, true);
  } else if (state.nextPredictedSong && (!state.currentSong || state.nextPredictedSong.id !== state.currentSong.id)) {
    if (userTriggered) {
      showToast(`AI DJ: Transitioning to ${state.nextPredictedSong.title}`);
    }
    loadSong(state.nextPredictedSong, true);
  } else if (state.currentSong) {
    showToast("AI DJ: Designing next tracks...");
    fetchRecommendations(state.currentSong.id, true);
  }
}

function playPrevSong() {
  if (state.history.length > 1) {
    state.history.pop(); // remove current
    const prevSong = state.history.pop();
    loadSong(prevSong, true);
  }
}

function handleSeek(e) {
  const rect = progressBarContainer.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const width = rect.width;
  const percentage = Math.max(0, Math.min(1, clickX / width));

  if (state.isUsingSynth) {
    // For synth mode, simple visual scrub
    progressBarFill.style.width = `${percentage * 100}%`;
    return;
  }

  if (audio.duration) {
    audio.currentTime = percentage * audio.duration;
  }
}

function updateTimeline() {
  if (state.isUsingSynth) return;
  const current = audio.currentTime || 0;
  const total = audio.duration || 30; // standard 30s preview
  const pct = (current / total) * 100;

  progressBarFill.style.width = `${pct}%`;
  currentTimeLabel.textContent = formatSeconds(current);
  totalDurationLabel.textContent = formatSeconds(total);
}

function formatSeconds(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

// ============================================================================
// THE ALGORITHM'S MIND: RECOMMENDATIONS & REASONING
// ============================================================================
async function fetchRecommendations(songId, playImmediate = false) {
  try {
    const url = `/api/recommendations/${songId}?mode=${state.currentMode}&count=12`;
    const res = await fetch(url);
    const data = await res.json();

    if (!data || !data.upcomingQueue) return;

    state.upcomingQueue = [...data.upcomingQueue];
    state.nextPredictedSong = data.primary_next || (data.upcomingQueue.length > 0 ? data.upcomingQueue[0] : null);

    if (playImmediate && state.nextPredictedSong) {
      loadSong(state.nextPredictedSong, true);
      return;
    }

    // Render "The Algorithm's Mind / Thinking HUD"
    if (state.nextPredictedSong && state.nextPredictedSong.algorithm_thinking) {
      renderAlgorithmThinking(state.currentSong, state.nextPredictedSong, state.nextPredictedSong.algorithm_thinking);
    }

    // Render Slide-over Up Next Queue
    renderQueueList(state.upcomingQueue);
  } catch (err) {
    console.error("Error fetching algorithmic recommendations:", err);
  }
}

function renderAlgorithmThinking(current, nextSong, thinking) {
  document.getElementById('brainStrategyDesc').textContent = thinking.strategy || 'Intelligent Multi-Parametric Match';

  // Next Track Preview Box
  document.getElementById('nextTrackTitle').textContent = nextSong.title;
  document.getElementById('nextTrackArtist').textContent = `${nextSong.artist} • ${nextSong.genre}`;
  document.getElementById('nextMatchValue').textContent = `${thinking.match_percentage}%`;

  // Fetch artwork for next track preview
  fetchArtworkThumbnail(nextSong.id, document.getElementById('nextTrackArt'));

  // Thought points
  const pointsList = document.getElementById('thoughtPointsList');
  pointsList.innerHTML = '';

  (thinking.thoughts || []).forEach(thought => {
    const item = document.createElement('div');
    item.className = 'thought-item';
    item.innerHTML = `<span class="thought-bullet"></span><span>${escapeHtml(thought)}</span>`;
    pointsList.appendChild(item);
  });

  // Parameter Comparison Radar Progress Bars
  const currVec = thinking.comparison.current;
  const nextVec = thinking.comparison.next;

  // Energy
  document.getElementById('paramValEnergy').textContent = `${(currVec.energy * 100).toFixed(0)}% → ${(nextVec.energy * 100).toFixed(0)}% (${thinking.deltas.energy >= 0 ? '+' : ''}${(thinking.deltas.energy * 100).toFixed(1)}%)`;
  document.getElementById('barCurrEnergy').style.width = `${currVec.energy * 100}%`;
  document.getElementById('barNextEnergy').style.width = `${nextVec.energy * 100}%`;

  // Danceability
  document.getElementById('paramValDance').textContent = `${(currVec.danceability * 100).toFixed(0)}% → ${(nextVec.danceability * 100).toFixed(0)}%`;
  document.getElementById('barCurrDance').style.width = `${currVec.danceability * 100}%`;
  document.getElementById('barNextDance').style.width = `${nextVec.danceability * 100}%`;

  // Valence (Happiness)
  document.getElementById('paramValValence').textContent = `${(currVec.valence * 100).toFixed(0)}% → ${(nextVec.valence * 100).toFixed(0)}%`;
  document.getElementById('barCurrValence').style.width = `${currVec.valence * 100}%`;
  document.getElementById('barNextValence').style.width = `${nextVec.valence * 100}%`;

  // Tempo (BPM)
  document.getElementById('paramValTempo').textContent = `${current.tempo} → ${nextSong.tempo} BPM (${thinking.deltas.tempo >= 0 ? '+' : ''}${thinking.deltas.tempo} BPM)`;
  document.getElementById('barCurrTempo').style.width = `${currVec.tempo_norm * 100}%`;
  document.getElementById('barNextTempo').style.width = `${nextVec.tempo_norm * 100}%`;

  // Acousticness
  document.getElementById('paramValAcoustic').textContent = `${(currVec.acousticness * 100).toFixed(0)}% → ${(nextVec.acousticness * 100).toFixed(0)}%`;
  document.getElementById('barCurrAcoustic').style.width = `${currVec.acousticness * 100}%`;
  document.getElementById('barNextAcoustic').style.width = `${nextVec.acousticness * 100}%`;
}

function renderQueueList(queue) {
  queueList.innerHTML = '';
  if (!queue || queue.length === 0) {
    queueList.innerHTML = `<div style="text-align:center; padding:30px 16px; color:var(--text-muted)">
      <div style="font-size:1.5rem; margin-bottom:8px;">⏳</div>
      <div>Loading algorithmic queue...</div>
    </div>`;
    return;
  }

  queue.forEach((song, idx) => {
    const card = document.createElement('div');
    card.className = 'queue-card';
    const matchScore = song.algorithm_thinking ? song.algorithm_thinking.match_percentage : '98.5';

    card.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px; width:100%;">
        <span style="font-size:0.75rem; color:var(--text-muted); width:18px; text-align:center;">${idx + 1}</span>
        <img src="${DEFAULT_ARTWORK}" data-songid="${song.id}" class="queue-card-art" alt="Art">
        <div class="queue-card-info">
          <div class="queue-card-title">${escapeHtml(song.title)}</div>
          <div class="queue-card-artist">${escapeHtml(song.artist)} • ${song.tempo} BPM</div>
        </div>
        <div class="queue-card-match">${matchScore}%</div>
        <button class="queue-play-btn" style="width:30px; height:30px; border-radius:50%; background:var(--spotify-green); border:none; display:flex; align-items:center; justify-content:center; cursor:pointer; flex-shrink:0; margin-left:6px;" title="Play Now">
          <svg viewBox="0 0 24 24" style="width:14px; height:14px; fill:#000; margin-left:2px;"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
        </button>
      </div>
    `;

    card.addEventListener('click', (e) => {
      // Remove from queue and play
      state.upcomingQueue.splice(idx, 1);
      renderQueueList(state.upcomingQueue);
      showToast(`Playing from queue: ${song.title}`);
      loadSong(song, true);
    });

    queueList.appendChild(card);
    fetchArtworkThumbnail(song.id, card.querySelector('.queue-card-art'));
  });
}

// ============================================================================
// REAL-TIME AUDIO VISUALIZER & WEB AUDIO SYNTHESIZER FALLBACK
// ============================================================================
function initAudioContext() {
  if (state.audioContext) return;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    state.audioContext = new AudioCtx();
    state.analyser = state.audioContext.createAnalyser();
    state.analyser.fftSize = 64;

    // Connect native audio to analyser
    state.audioSource = state.audioContext.createMediaElementSource(audio);
    state.audioSource.connect(state.analyser);
    state.analyser.connect(state.audioContext.destination);
  } catch (e) {
    console.warn("Web Audio API not fully allowed until user interaction:", e);
  }
}

function setupVisualizer() {
  const render = () => {
    requestAnimationFrame(render);
    drawVisualizerFrame();
  };
  render();
}

function startVisualizer() {
  state.isVisualizerRunning = true;
}

function drawVisualizerFrame() {
  const width = canvas.width;
  const height = canvas.height;
  canvasCtx.clearRect(0, 0, width, height);

  const numBars = 18;
  const barWidth = (width / numBars) - 2;

  if (state.isPlaying && state.analyser) {
    const dataArray = new Uint8Array(state.analyser.frequencyBinCount);
    state.analyser.getByteFrequencyData(dataArray);

    for (let i = 0; i < numBars; i++) {
      const dataIdx = Math.floor(i * (dataArray.length / numBars));
      const val = dataArray[dataIdx] || 0;
      const barHeight = Math.max(3, (val / 255) * height);

      const x = i * (barWidth + 2);
      const y = height - barHeight;

      // Glow gradient: Spotify Green to Cyan
      const grad = canvasCtx.createLinearGradient(0, y, 0, height);
      grad.addColorStop(0, '#1DB954');
      grad.addColorStop(1, '#00e5ff');

      canvasCtx.fillStyle = grad;
      canvasCtx.beginPath();
      canvasCtx.roundRect(x, y, barWidth, barHeight, [2, 2, 0, 0]);
      canvasCtx.fill();
    }
  } else {
    // Idle gentle wave
    const time = Date.now() * 0.003;
    for (let i = 0; i < numBars; i++) {
      const wave = Math.sin(time + i * 0.4) * 0.5 + 0.5;
      const barHeight = state.isPlaying ? (wave * (height - 6) + 4) : 4;
      const x = i * (barWidth + 2);
      const y = height - barHeight;

      canvasCtx.fillStyle = 'rgba(255, 255, 255, 0.15)';
      canvasCtx.beginPath();
      canvasCtx.roundRect(x, y, barWidth, barHeight, [2, 2, 0, 0]);
      canvasCtx.fill();
    }
  }
}

/**
 * Web Audio Melodic Synthesizer
 * Guarantees that EVERY song can play music, even if external iTunes preview is offline!
 */
function playWithSynthesizer(song, autoPlay = true) {
  stopSynthesizer();
  state.isUsingSynth = true;
  initAudioContext();

  if (!autoPlay || !state.audioContext) {
    setPlayingUI(false);
    return;
  }

  if (state.audioContext.state === 'suspended') {
    state.audioContext.resume();
  }

  state.isPlaying = true;
  setPlayingUI(true);

  // Musical notes derived from song's key and tempo
  const baseFreqs = [130.81, 146.83, 164.81, 174.61, 196.00, 220.00, 246.94]; // C3 scale
  const rootFreq = baseFreqs[(song.key || 0) % 7];
  const bpm = song.tempo || 120;
  const beatInterval = (60 / bpm) * 1000;

  let step = 0;
  let synthTime = 0;

  state.synthInterval = setInterval(() => {
    if (!state.isPlaying) return;

    synthTime += beatInterval / 1000;
    const totalPreview = 30; // 30 second preview
    const pct = Math.min(100, (synthTime / totalPreview) * 100);
    progressBarFill.style.width = `${pct}%`;
    currentTimeLabel.textContent = formatSeconds(synthTime);
    totalDurationLabel.textContent = formatSeconds(totalPreview);

    if (synthTime >= totalPreview) {
      stopSynthesizer();
      onTrackEnded();
      return;
    }

    try {
      const osc = state.audioContext.createOscillator();
      const gain = state.audioContext.createGain();

      // Arpeggio notes based on step
      const noteOffsets = [1, 1.25, 1.5, 1.875, 2];
      const freq = rootFreq * noteOffsets[step % noteOffsets.length];

      osc.type = song.mood_cluster === 1 ? 'sawtooth' : (song.mood_cluster === 4 ? 'sine' : 'triangle');
      osc.frequency.setValueAtTime(freq, state.audioContext.currentTime);

      gain.gain.setValueAtTime(0.08 * (audio.volume || 0.8), state.audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, state.audioContext.currentTime + 0.35);

      osc.connect(gain);
      if (state.analyser) {
        gain.connect(state.analyser);
      }
      gain.connect(state.audioContext.destination);

      osc.start();
      osc.stop(state.audioContext.currentTime + 0.38);
    } catch (e) {
      // Audio context might be waiting on gesture
    }

    step++;
  }, Math.max(180, beatInterval / 2));
}

function stopSynthesizer() {
  if (state.synthInterval) {
    clearInterval(state.synthInterval);
    state.synthInterval = null;
  }
}

function handleAudioPlaybackError(e) {
  console.warn("Audio element encountered error, activating synthesizer fallback:", e);
  if (state.currentSong) {
    playWithSynthesizer(state.currentSong, state.isPlaying);
  }
}

// ============================================================================
// DIJKSTRA SHORT-PATH BRIDGE (DSA2 SHOWCASE)
// ============================================================================
function populateDijkstraDropdowns(songs) {
  dijkstraStartSelect.innerHTML = '';
  dijkstraTargetSelect.innerHTML = '';

  songs.slice(0, 40).forEach(song => {
    const opt1 = document.createElement('option');
    opt1.value = song.id;
    opt1.textContent = `${song.title} - ${song.artist} (${song.mood_name})`;

    const opt2 = document.createElement('option');
    opt2.value = song.id;
    opt2.textContent = `${song.title} - ${song.artist} (${song.mood_name})`;

    dijkstraStartSelect.appendChild(opt1);
    dijkstraTargetSelect.appendChild(opt2);
  });

  if (dijkstraTargetSelect.options.length > 5) {
    dijkstraTargetSelect.selectedIndex = 5;
  }
}

function openDijkstraModalWithCurrent() {
  dijkstraModal.classList.add('open');
  if (state.currentSong) {
    // Check if current song is in dropdown, else add it
    let exists = false;
    for (let opt of dijkstraStartSelect.options) {
      if (parseInt(opt.value) === state.currentSong.id) {
        exists = true;
        break;
      }
    }
    if (!exists) {
      const opt = document.createElement('option');
      opt.value = state.currentSong.id;
      opt.textContent = `★ ${state.currentSong.title} - ${state.currentSong.artist}`;
      dijkstraStartSelect.insertBefore(opt, dijkstraStartSelect.firstChild);
    }
    dijkstraStartSelect.value = state.currentSong.id;
  }
}

async function runDijkstraPathfinding() {
  const startId = dijkstraStartSelect.value;
  const targetId = dijkstraTargetSelect.value;

  if (startId === targetId) {
    showToast("Please choose two different songs to calculate a musical bridge.");
    return;
  }

  btnCalculatePath.textContent = "Computing Graph Shortest Path (Min-Heap)...";
  btnCalculatePath.disabled = true;

  try {
    const res = await fetch(`/api/dijkstra?start_id=${startId}&target_id=${targetId}`);
    const data = await res.json();

    btnCalculatePath.textContent = "Run Dijkstra Shortest Path";
    btnCalculatePath.disabled = false;

    if (!data.path || data.path.length === 0) {
      showToast("Could not find a path between these songs.");
      return;
    }

    dijkstraResultsArea.style.display = 'flex';
    pathHopsSummary.textContent = `Musical Shortest Path Found: ${data.hops} Steps (Graph Dijkstra with Priority Queue)`;
    pathStepsContainer.innerHTML = '';

    data.path.forEach((step, idx) => {
      const card = document.createElement('div');
      card.className = 'path-step-card';
      const isStart = idx === 0;
      const isEnd = idx === data.path.length - 1;

      card.innerHTML = `
        <div class="path-step-badge">${idx + 1}</div>
        <div class="path-step-info">
          <div class="path-step-title">${escapeHtml(step.title)} <span style="font-size:0.75rem; color:${step.mood_color}">(${step.mood_name})</span></div>
          <div class="path-step-meta">${escapeHtml(step.artist)} • ${step.tempo} BPM • ${step.genre}</div>
        </div>
        <button class="hero-secondary-btn" style="padding:4px 10px; font-size:0.75rem;" data-playid="${step.id}">Play</button>
      `;

      card.querySelector('button').addEventListener('click', () => {
        loadSong(step, true);
        dijkstraModal.classList.remove('open');
      });

      pathStepsContainer.appendChild(card);
    });
  } catch (err) {
    console.error("Dijkstra error:", err);
    btnCalculatePath.textContent = "Run Dijkstra Shortest Path";
    btnCalculatePath.disabled = false;
  }
}

// ============================================================================
// FAVORITES & LIKES (PERSISTED)
// ============================================================================
function toggleFavorite(songId) {
  if (state.favorites.has(songId)) {
    state.favorites.delete(songId);
    showToast("Removed from Liked Songs");
  } else {
    state.favorites.add(songId);
    showToast("Saved to Liked Songs ♥");
  }
  localStorage.setItem('spotify_favs', JSON.stringify([...state.favorites]));
  updateFavoritesCount();
}

function updateFavoritesCount() {
  document.getElementById('favCount').textContent = state.favorites.size;
}

function updatePlayerLikeBtn() {
  if (!state.currentSong) return;
  const isLiked = state.favorites.has(state.currentSong.id);
  document.getElementById('playerLikeBtn').classList.toggle('liked', isLiked);
}

function renderFavoritesView() {
  if (state.favorites.size === 0) {
    trackTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:40px; color:var(--text-muted)">No liked songs yet. Click the heart icon on any song to save it!</td></tr>`;
    document.getElementById('sectionHeading').textContent = "Liked Songs";
    document.getElementById('trackCountBadge').textContent = "0 tracks";
    return;
  }

  const favSongs = [];
  state.favorites.forEach(id => {
    const s = state.trackCache.get(id);
    if (s) favSongs.push(s);
  });

  renderTrackTable(favSongs);
  document.getElementById('sectionHeading').textContent = "Your Liked Songs";
  document.getElementById('trackCountBadge').textContent = `${favSongs.length} tracks`;
}

// ============================================================================
// UTILITIES & HELPERS
// ============================================================================
async function fetchArtworkThumbnail(songId, imgElement) {
  if (!imgElement) return;
  const song = state.trackCache.get(songId);
  if (!song) return;

  try {
    const res = await fetch(`/api/preview?id=${songId}`);
    const data = await res.json();
    if (data.artwork_url) {
      imgElement.src = data.artwork_url;
    }
  } catch (e) {
    // Ignore thumbnail error and keep placeholder
  }
}

function setDynamicMoodColor(hex) {
  document.documentElement.style.setProperty('--mood-accent', hex);
  // Convert hex to rgb
  const r = parseInt(hex.slice(1, 3), 16) || 29;
  const g = parseInt(hex.slice(3, 5), 16) || 185;
  const b = parseInt(hex.slice(5, 7), 16) || 84;
  document.documentElement.style.setProperty('--mood-accent-rgb', `${r}, ${g}, ${b}`);
}

function showToast(msg) {
  toastMsg.textContent = msg;
  toastMsg.classList.add('show');
  setTimeout(() => toastMsg.classList.remove('show'), 2600);
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
